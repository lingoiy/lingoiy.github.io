let aboba = 0
let clickPlus = 1;
document.getElementById('aboba').onclick = function() {
  aboba += clickPlus;
  document.getElementById('aabb').textContent = "abobas: " + aboba;
 document.getElementById('tomakenull').hidden = false;
  
};
document.getElementById('tomakenull').onclick = function() {
  aboba = 0;
  document.getElementById('aabb').textContent = "abobas: 0";
  document.getElementById('tomakenull').hidden = true;
};