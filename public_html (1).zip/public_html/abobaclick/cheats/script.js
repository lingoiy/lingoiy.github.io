console.log('чтобы увеличить кол-во абоб при клике нажмите f12 в кликере и напишите "clickPlus = сколько_кликов_вы_хотите"')
let aboba = 'document.querySelector(<#aboba>)'
console.log('чтобы поставить определённое кол-во кликов тоже f12 и "aboba = 1" и ' + aboba + ' (<> = "")')
console.log('Удачи')
console.log('А вообще читы - это плохо')